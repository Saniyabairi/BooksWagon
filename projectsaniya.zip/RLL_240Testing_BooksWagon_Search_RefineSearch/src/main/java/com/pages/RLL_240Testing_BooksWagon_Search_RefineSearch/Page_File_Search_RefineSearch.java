package com.pages.RLL_240Testing_BooksWagon_Search_RefineSearch;
import org.openqa.selenium.By; 

import org.openqa.selenium.WebDriver; 

import org.openqa.selenium.WebElement; 

 

public class Page_File_Search_RefineSearch { 

    private WebDriver driver; 

 

    // Locators 

    private By searchBox = By.id("inputbar"); 

    private By searchButton = By.id("btnTopSearch"); 

    private By searchResults = By.xpath("/a[@href='https://www.bookswagon.com/book/rahasya-secret-byrne-rhonda/9788183220941']"); // Replace with actual locator 

    private By noResultsMessage = By.xpath("//div[@class='not-match' and contains(text(), 'did not match any books')]\r\n"); // Replace with actual locator 

     

    // Constructor 

    public Page_File_Search_RefineSearch(WebDriver driver) { 

        this.driver = driver; 

    } 

 

    // Method to enter search item 

    public void enterSearchItem(String item) { 

        WebElement searchBoxElement = driver.findElement(searchBox); 

        searchBoxElement.sendKeys(item); 

        searchBoxElement.clear(); 

    } 

 

    // Method to click the search button 

    public void clickSearchButton() throws InterruptedException { 

        driver.findElement(searchButton).click(); 

        Thread.sleep(1000); 

    } 

     

 // Method to get the search results 

    public void getSearchResults() throws InterruptedException { 

        driver.findElement(searchResults).getText(); 

        Thread.sleep(2000); 

    } 

    // Method to get the no results message 

    public void getNoResultsMessage() throws InterruptedException { 

        driver.findElement(noResultsMessage).getText(); 

        Thread.sleep(1000); 

    }   

} 