package com.Runner_File1;


import io.cucumber.testng.AbstractTestNGCucumberTests; 
import io.cucumber.testng.CucumberOptions; 

@CucumberOptions(features = "src/test/java/com/features/Search_RefineSearch", 
glue = "com.StepDefinition", 
plugin = {"pretty", "html:target/cucumber-reports.html"}, 
tags = " @bookswagon or @SearchAndRefineSearch", 
monochrome = true 

		) 

public class RunnerTestNG extends AbstractTestNGCucumberTests{ 
}     
