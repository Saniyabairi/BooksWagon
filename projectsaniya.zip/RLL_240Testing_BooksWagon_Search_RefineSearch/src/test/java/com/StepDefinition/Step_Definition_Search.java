package com.StepDefinition;
import org.openqa.selenium.By; 
import org.openqa.selenium.WebDriver; 
import org.openqa.selenium.WebElement; 
import org.openqa.selenium.chrome.ChromeDriver; 
import io.cucumber.java.Before; 
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When; 
import io.cucumber.java.en.Then; 
import org.testng.Assert;
import org.testng.log4testng.Logger;
import com.pages.RLL_240Testing_BooksWagon_Search_RefineSearch.Page_File_Search_RefineSearch; 
public class Step_Definition_Search { 

	WebDriver driver;  

	Page_File_Search_RefineSearch sr1; 
    //Logger log2;
	
	@Before 

	public void init() 
	{ 
		driver=new ChromeDriver();	 

		sr1 = new Page_File_Search_RefineSearch(driver);
	//log2=Logger.getLogger(Step_Definition_Search.class);

	} 



	@Given("the user is on Search_Result page") 

	public void userIsOnSearch_ResultPage() { 
		driver.get("https://www.bookswagon.com/search-books/the-secret"); 
		//log2.info("user is on Search_Result page");
		

	} 


	@When("^the user gives (.*) in the search box $") 

	public void enterSearchItem(String input) { 

		driver.findElement(By.id("inputbar")).sendKeys(input); 

		sr1.enterSearchItem("The secret"); 

	} 

	@When("click on the search button") 

	public void clickSearchButton() throws InterruptedException { 

		driver.findElement(By.id("btnTopSearch")).click(); 

		sr1.clickSearchButton(); 

	} 
	@Then("the user should see expected_result") 

	public void verifySearchResults(String expectedResult) { 

		if (expectedResult.equals("Your search - '16354e4@$43' - did not match any books.")) { 

			// Locate the element that contains the no results message 

			//WebElement noResultsMessageElement = driver.findElement(By.id("noResultsMessageId")); // Use the appropriate locator 

			//String actualMessage = noResultsMessageElement.getText(); 

			//		Assert.assertTrue(actualMessage.contains(expectedResult)); 
			System.out.print("Opening");

		} else { 

			// Locate the element that contains the search results 

			//WebElement searchResultsElement = driver.findElement(By.id("searchResultsId")); // Use the appropriate locator 

			//String actualResult = searchResultsElement.getText(); 

			//	Assert.assertTrue(actualResult.contains(expectedResult)); 
			System.out.print("Closing");

		} 
	} 

}
